<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('setup/manage-nav.php'); ?>
<?php include('main/footer.php'); ?>