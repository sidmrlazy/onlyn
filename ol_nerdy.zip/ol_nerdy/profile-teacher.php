<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('users/teacher-profile.php'); ?>
<?php include('main/footer.php'); ?>