<div class="container section-container mb-5">
    <a href="add-student.php" class="custom-tab">
        <ion-icon class="tab-icon" name="person-add-outline"></ion-icon>
        <p>Add Student</p>
        <ion-icon class="tab-icon-right" name="caret-forward-outline"></ion-icon>
    </a>
    <a href="view-student.php" class="custom-tab">
        <ion-icon class="tab-icon" name="eye-outline"></ion-icon>
        <p>View | Edit Student Data</p>
        <ion-icon class="tab-icon-right" name="caret-forward-outline"></ion-icon>
    </a>
</div>