<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('dashboard/dashboard-parent.php'); ?>
<?php include('main/footer.php'); ?>