<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('classes/view-form.php'); ?>
<?php include('main/footer.php'); ?>