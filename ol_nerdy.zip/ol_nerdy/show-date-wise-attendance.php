<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('school/show-date-wise-attendance.php'); ?>
<?php include('main/footer.php'); ?>