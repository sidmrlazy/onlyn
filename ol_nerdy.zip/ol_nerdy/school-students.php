<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('school/show-classes.php'); ?>
<?php include('main/footer.php'); ?>