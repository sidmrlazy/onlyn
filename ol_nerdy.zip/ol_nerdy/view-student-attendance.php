<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('teacher/view-attendance.php'); ?>
<?php include('main/footer.php'); ?>