<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('classes/add-subject-form.php'); ?>
<?php include('main/footer.php'); ?>