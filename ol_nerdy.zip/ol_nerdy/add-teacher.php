<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('users/add-teacher-form.php'); ?>
<?php include('main/footer.php'); ?>