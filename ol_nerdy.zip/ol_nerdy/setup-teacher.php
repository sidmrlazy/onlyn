<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('setup/profile-progress-bar.php'); ?>
<?php include('setup/school-setup-tabs.php'); ?>
<?php include('main/footer.php'); ?>