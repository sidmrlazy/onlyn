<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('users/add-staff-form.php'); ?>
<?php include('main/footer.php'); ?>