<?php include('main/header.php') ?>
<?php include('main/web-navbar.php') ?>
<?php include('main/register-form.php') ?>
<?php include('main/footer.php') ?>