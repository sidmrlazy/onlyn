<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('teacher/add-student-form.php'); ?>
<?php include('main/footer.php'); ?>