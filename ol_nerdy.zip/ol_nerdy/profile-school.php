<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('users/school-profile.php'); ?>
<?php include('main/footer.php'); ?>