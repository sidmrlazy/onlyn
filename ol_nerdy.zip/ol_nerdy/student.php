<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('teacher/student-nav.php'); ?>
<?php include('main/footer.php'); ?>