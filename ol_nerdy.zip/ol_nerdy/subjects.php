<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('setup/school-setup-nav/add-subject-form.php'); ?>
<?php include('main/footer.php'); ?>