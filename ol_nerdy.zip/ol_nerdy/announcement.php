<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('setup/announcement.php'); ?>
<?php include('main/footer.php'); ?>