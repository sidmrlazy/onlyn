<?php include('main/header.php'); ?>
<?php include('main/navbar-school.php'); ?>
<?php include('dashboard/dashboard-school.php'); ?>
<?php // include('dashboard/feature-test.php'); 
?>
<?php include('main/footer.php'); ?>