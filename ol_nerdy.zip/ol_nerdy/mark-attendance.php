<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('teacher/mark-attendance.php'); ?>
<?php include('main/footer.php'); ?>