<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('teacher/edit-student.php'); ?>
<?php include('main/footer.php'); ?>