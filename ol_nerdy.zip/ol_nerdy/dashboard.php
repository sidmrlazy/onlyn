<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('dashboard/dashboard.php'); ?>
<?php include('main/footer.php'); ?>