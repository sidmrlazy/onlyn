<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('teacher/select-attendance-date.php'); ?>
<?php include('main/footer.php'); ?>