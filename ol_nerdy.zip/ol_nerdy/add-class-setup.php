<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('setup/school-setup-nav/add-class.php'); ?>
<?php include('main/footer.php'); ?>