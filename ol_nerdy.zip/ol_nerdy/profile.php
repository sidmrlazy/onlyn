<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('setup/profile-form.php'); ?>
<?php include('main/footer.php'); ?>