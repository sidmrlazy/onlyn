<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('classes/add-form.php'); ?>
<?php include('main/footer.php'); ?>