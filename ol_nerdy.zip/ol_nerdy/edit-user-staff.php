<?php include('main/header.php'); ?>
<?php include('main/navbar.php'); ?>
<?php include('setup/school-setup-nav/edit-staff-details.php'); ?>
<?php include('main/footer.php'); ?>